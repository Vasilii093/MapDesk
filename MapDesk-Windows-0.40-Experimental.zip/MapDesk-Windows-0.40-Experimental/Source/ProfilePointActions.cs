﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace AlpineQuestPort {
 internal static class ProfilePointActions {
  internal static GeoPoint At(TerrainProfile profile,ProfileAxes axes,Point location){if(profile==null||axes==null)return null;int i=axes.Sample(location,profile.Points.Length);if(i<0)return null;var p=profile.Points[i];return new GeoPoint(p.Lat,p.Lon){Elevation=GeoMath.IsFinite(profile.Heights[i])?(double?)profile.Heights[i]:null,Name="Профиль · "+(profile.X[i]/1000).ToString("0.000")+" км"};}
  internal static void Menu(Control control,Point location,GeoPoint point,Action<GeoPoint> add,Action<GeoPoint> locate){if(point==null)return;var menu=new ContextMenuStrip();menu.Items.Add("Добавить точку на карту",null,delegate{add(point);});menu.Items.Add("Перейти к точке на карте",null,delegate{locate(point);});menu.Closed+=delegate{var context=System.Threading.SynchronizationContext.Current;if(context!=null)context.Post(state=>menu.Dispose(),null);else menu.Dispose();};menu.Show(control,location);}
 }
 sealed partial class MapCanvas {
  internal void AddProfilePoint(GeoPoint source){if(source==null)return;var point=new GeoPoint(source.Lat,source.Lon){Name=source.Name,Elevation=source.Elevation,Group="Точки профилей",ColorRgb=0xFFB000};Document.Waypoints.Add(point);Changed();Say("Точка профиля добавлена. Правой кнопкой — переход к месту на карте.");}
 }
}
